#include <QtQuick/QQuickView>
#include <Terrain3D/Library.h>

int main(int argc, char **argv)
{
	//setup a dummy context for all of our OpenGL calls
//	QGuiApplication app(argc, argv);
//	QQuickView window;
//	window.setResizeMode(QQuickView::SizeRootObjectToView);
//	window.setSource(QUrl("qrc:///main.qml"));
//	window.show();
//	window.hide();

//	//run the tests
//	::testing::InitGoogleTest(&argc, argv);
//	return RUN_ALL_TESTS();

    return 0;
}
